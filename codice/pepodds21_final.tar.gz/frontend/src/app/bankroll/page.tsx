'use client';

import useSWR from 'swr';
import { api, BetStats, PipelineRun } from '@/lib/api';
import StatCard from '@/components/StatCard';

const fmt = (n: number, d = 2) =>
  new Intl.NumberFormat('it-IT', { minimumFractionDigits: d, maximumFractionDigits: d }).format(n);

export default function PipelinePage() {
  const { data: betStats } = useSWR<BetStats>('bet-stats-pipeline', api.getBetStats, { refreshInterval: 30000 });
  const { data: runs } = useSWR<PipelineRun[]>('pipeline-runs', api.getPipelineRuns, { refreshInterval: 60000 });

  const totalBets = betStats?.total_bets ?? 0;
  const staked = betStats?.total_staked ?? 0;
  const pnl = betStats?.total_pnl ?? 0;
  const roi = betStats?.roi_pct ?? 0;

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-3xl font-semibold text-brand-text">Pipeline</h1>
        <p className="text-brand-muted text-sm mt-1">Attività del sistema e storico esecuzioni</p>
      </div>

      {/* KPI sintetici */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <StatCard
          label="Totale puntato"
          value={staked > 0 ? `€ ${fmt(staked)}` : '€ 0'}
          sub={`${totalBets} scommes${totalBets === 1 ? 'sa' : 'se'}`}
        />
        <StatCard
          label="P&L netto"
          value={staked > 0 ? `${pnl >= 0 ? '+' : ''}€ ${fmt(Math.abs(pnl))}` : '€ 0'}
          sub={staked > 0 ? `ROI: ${roi >= 0 ? '+' : ''}${fmt(roi, 1)}%` : 'Nessuna scommessa'}
          color={pnl > 0 ? 'green' : pnl < 0 ? 'red' : undefined}
        />
        <StatCard
          label="Vinte"
          value={betStats?.won ?? 0}
          color="green"
        />
        <StatCard
          label="Perse"
          value={betStats?.lost ?? 0}
          color="red"
        />
      </div>

      {/* Pipeline runs */}
      {runs && runs.length > 0 ? (
        <div className="bg-white rounded-card shadow-card p-6">
          <h2 className="text-base font-semibold text-brand-text mb-4">Ultime esecuzioni pipeline</h2>
          <div className="space-y-2">
            {runs.map(r => (
              <div key={r.id} className="flex items-center justify-between p-3 bg-brand-bg rounded-xl">
                <div>
                  <div className="text-sm font-medium text-brand-text">
                    {new Date(r.started_at).toLocaleString('it-IT')}
                  </div>
                  <div className="text-xs text-brand-muted">
                    {r.matches_processed} partite · {r.opportunities_found} opportunità · {r.bets_placed} scommesse
                  </div>
                  {r.error && <div className="text-xs text-brand-red mt-0.5">{r.error}</div>}
                </div>
                <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${
                  r.status === 'done'    ? 'bg-green-100 text-brand-green' :
                  r.status === 'running' ? 'bg-blue-50 text-brand-blue' :
                  'bg-red-100 text-brand-red'}`}>
                  {r.status === 'done' ? 'completata' : r.status === 'running' ? 'in corso' : 'errore'}
                </span>
              </div>
            ))}
          </div>
        </div>
      ) : (
        <div className="bg-white rounded-card shadow-card p-8 text-center text-brand-muted">
          <div className="text-3xl mb-2">⚙️</div>
          <div className="font-medium">Nessuna esecuzione ancora</div>
          <div className="text-sm mt-1">La pipeline gira automaticamente alle 09:45 e 17:00 UTC</div>
        </div>
      )}
    </div>
  );
}
